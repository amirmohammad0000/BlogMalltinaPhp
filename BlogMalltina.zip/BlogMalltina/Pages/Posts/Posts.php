<?php
require_once "./../../Assets/Database/DbConfig.php";

if (isset($_POST["ButtonSubmit"])) {
  if (
    isset($_POST["ContentComment"]) && $_POST["ContentComment"] !== ""
    && isset($_POST["EmailUser"]) && $_POST["EmailUser"] !== ""
    && isset($_POST["NameUser"]) && $_POST["NameUser"] !== ""
  ) {
    $PostId = $_REQUEST['PostId'];
    $query = "INSERT INTO `comments` 
    (PostId, StatusComment, ImageComment, UserNameComment, ContentComment, Email)
    VALUES
    ($PostId, 0, './Pages/Posts/Assets/Images/Profile.png', ?, ?, ?)";
    $statement = $conn->prepare($query);
    $statement->execute([$_POST["NameUser"] . ' on' . ' ', $_POST["ContentComment"], $_POST["EmailUser"]]);
  }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0" />
  <meta http-equiv="X-UA-Compatible" content="ie=edge" />
  <title>Posts</title>
  <!-- Start Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.0/css/all.min.css" />
  <!-- Start Custom Css -->
  <link rel="stylesheet" href="./Assets/CustomCssJs/Style.css" />
  <!-- End Custom Css -->
</head>

<body>
  <section class="section_app_blog">
    <section class="section_header_blog">
      <section class="section_inner_section_header_blog section_inner_section_header_blog_one">
        <a href="./../../index.php" class="tag_a_section_inner_section_header_blog">BLOG</a>
      </section>

      <section class="section_inner_section_header_blog">
        <a href="./../../index.php" class="tag_a_section_inner_section_header_blog">خانه</a>
      </section>

      <section class="section_inner_section_header_blog">
        <a href="https://malltina.com/" class="tag_a_section_inner_section_header_blog">فروشگاه مالتینا</a>
      </section>

      <section class="section_inner_section_header_blog">
        <i class="fa-solid fa-arrow-down"></i>

        <span class="text_open_close_menu_news_and_festivals">
          اخبار و جشنواه‌ها
        </span>

        <section class="section_menu_section_inner_section_header_blog_news">
          <section class="section_inner_menu_section_inner_section_header_blog_news">
            <a href="./../../Pages/NewsAndFestivals/News/News.php" class="tag_a_menu_section_menu_section_inner_section_header_blog_news">
              اخبار مالتینا
            </a>
          </section>

          <section class="section_inner_menu_section_inner_section_header_blog_news">
            <a href="./../../Pages/NewsAndFestivals/Festival/Festival.php" class="tag_a_menu_section_menu_section_inner_section_header_blog_news">جشنواره و تخفیف های مالتینا
            </a>
          </section>
        </section>
      </section>

      <section class="section_inner_section_header_blog">
        <i class="fa-solid fa-arrow-down"></i>

        <span class="text_open_close_menu_content">دسته‌بندی مطالب</span>

        <section class="section_menu_section_inner_section_header_blog_content">
          <section class="section_inner_menu_section_inner_section_header_blog_content">
            <a href="./../../Pages/ContentCategory/GeneralInformation/GeneralInformation.php" class="tag_a_section_menu_section_inner_section_header_blog_content">اطلاعات عمومی</a>
          </section>

          <section class="section_inner_menu_section_inner_section_header_blog_content">
            <a href="./../../Pages/ContentCategory/WomenMagazine/WomenMagazine.php" class="tag_a_section_menu_section_inner_section_header_blog_content">
              مجله بانوان
            </a>
          </section>

          <section class="section_inner_menu_section_inner_section_header_blog_content">
            <a href="./../../Pages/ContentCategory/ScienceAndTechnology/ScienceAndTechnology.php" class="tag_a_section_menu_section_inner_section_header_blog_content">
              علم و تکنولوژی
            </a>
          </section>

          <section class="section_inner_menu_section_inner_section_header_blog_content">
            <a href="./../../Pages/ContentCategory/WorldArtAndCinema/WorldArtAndCinema.php" class="tag_a_section_menu_section_inner_section_header_blog_content">
              هنر و سینمای جهان
            </a>
          </section>

          <section class="section_inner_menu_section_inner_section_header_blog_content">
            <a href="./../../Pages/ContentCategory/ReviewAndDownloadMoviesAndSeries/ReviewAndDownloadMoviesAndSeries.php" class="tag_a_section_menu_section_inner_section_header_blog_content">
              نقد و دانلود فیلم و سریال
            </a>
          </section>

          <section class="section_inner_menu_section_inner_section_header_blog_content">
            <a href="./../../Pages/ContentCategory/ModeAndFashion/ModeAndFashion.php" class="tag_a_section_menu_section_inner_section_header_blog_content">
              مد و فشن</a>
          </section>

          <section class="section_inner_menu_section_inner_section_header_blog_content">
            <a href="./../../Pages/ContentCategory/ProductIntroduction/ProductIntroduction.php" class="tag_a_section_menu_section_inner_section_header_blog_content">
              معرفی محصول
            </a>
          </section>

          <section class="section_inner_menu_section_inner_section_header_blog_content">
            <a href="./../../Pages/ContentCategory/SkillsAndBusiness/SkillsAndBusiness.php" class="tag_a_section_menu_section_inner_section_header_blog_content">
              مهارت و کسب‌ و کار
            </a>
          </section>

          <section class="section_inner_menu_section_inner_section_header_blog_content">
            <a href="./../../Pages/ContentCategory/Other/Other.php" class="tag_a_section_menu_section_inner_section_header_blog_content">
              سایر
            </a>
          </section>
        </section>
      </section>

      <section class="section_inner_section_header_blog">
        <a href="./../../Pages/PurchaseGuide/PurchaseGuide.php" class="tag_a_section_inner_section_header_blog">راهنمای خرید</a>
      </section>

      <section class="section_inner_section_header_blog">
        <a href="./../../index.php" class="tag_a_section_inner_section_header_blog">RSS</a>
      </section>
    </section>

    <section class="section_content_blog">
      <section class="section_inner_content_blog">
        <?php
        $PostId = $_REQUEST['PostId'];
        $query = "SELECT * FROM `posts` WHERE `Id` = $PostId";
        $statement = $conn->prepare($query);
        $statement->execute();
        $Post = $statement->fetch();
        ?>
        <section class="section_image_post_section_inner_content_blog">
          <img src="./../../<?= $Post->ImagePost ?>" alt="Post" class="image_section_image_post_section_inner_content_blog" />
        </section>

        <section class="section_main_section_inner_content_blog">
          <section class="section_right_section_main_section_inner_content_blog">
            <section class="section_text_right_section_main_section_inner_content_blog">
              <?= $Post->ContentPost ?>
            </section>

            <p class="text_section_right_section_main_section_inner_content_blog">
              منبع: <a href="<?= $Post->LickSourcePosts ?>"><?= $Post->SourcePost ?></a>
            </p>

            <section class=" section_share_article_section_main_section_inner_content_blog">
              <section class="section_inner_share_article_section_main_section_inner_content_blog">
                <p>Share Article:</p>

                <i class="fa-brands fa-whatsapp"></i>

                <i class="fa-brands fa-telegram"></i>

                <i class="fa-brands fa-twitter"></i>

                <i class="fa-brands fa-facebook"></i>
              </section>

              <section class="section_copy_address_page_section_right">
                <p>
                  <script>
                    document.write(window.location.href);
                  </script>
                </p>

                <i class="fa-solid fa-copy"></i>
              </section>
            </section>

            <section class="section_post_next_prev_section_right">
              <section class="section_post_prev_section_post_next_prev_section_right">
                <img src="./Assets/Images/PostOne.png" alt="" class="image_section_post_prev_section_post_next_prev_section_right" />

                <p>
                  نشانه هایی که داد میزند شما از نظر دیگران چهره زیبایی دارید!
                </p>

                <i class="fas fa-arrow-left"></i>
              </section>

              <section class="section_post_next_section_post_next_prev_section_right">
                <img src="./Assets/Images/PostFive.png" alt="" class="image_section_post_next_section_post_next_prev_section_right" />

                <p>گچ خوراکی چیست؟ بررسی و خرید انواع گچ خوراکی</p>

                <i class="fas fa-arrow-right"></i>
              </section>
            </section>

            <section class="section_comments_section_right">
              <section class="section_text_header_section_comments_section_right">
                <p>Comments</p>
                <span>40</span>
              </section>

              <?php
              $PostId = $_REQUEST['PostId'];
              $query = "SELECT * FROM `comments` WHERE `StatusComment` = 1 AND `PostId` = $PostId";
              $statement = $conn->prepare($query);
              $statement->execute();
              $Comments = $statement->fetchAll();

              foreach ($Comments as $Comment) {
              ?>
                <section class="section_comment_section_comments_section_right">
                  <section class="section_image_section_comment_section_comments_section_right">
                    <img src="./../../<?= $Comment->ImageComment ?>" alt="Profile" class="image_section_image_section_comment_section_comments_section_right" />
                  </section>

                  <section class="section_texts_section_comment_section_comments_section_right">
                    <p class="text_section_comment_section_comments_section_right">
                      <?= $Comment->UserNameComment ?>
                    </p>

                    <p class="text_content_comment_section_comment_section_comments_section_right">
                      <?= $Comment->ContentComment ?>
                    </p>

                    <section class="button_answer_section_comment_section_comments_section_right">
                      پاسخ
                    </section>
                  </section>
                </section>
              <?php } ?>
            </section>

            <section class="section_write_comment">
              <p>دیدگاهتان را بنویسید</p>

              <form class="section_textarea_section_write_comment" action="" method="POST">
                <textarea cols="30" rows="10" name="ContentComment" placeholder="Comment"></textarea>

                <section class="section_input_section_write_comment">
                  <input type="text" name="EmailUser" placeholder="Email" />

                  <input type="text" name="NameUser" placeholder="Name" />
                </section>

                <button type="submit" name="ButtonSubmit" class="section_button_section_write_comment">
                  فرستادن دیدگاه
                </button>
              </form>
            </section>
          </section>

          <section class="section_left_section_main_section_inner_content_blog">
            <form action="./../Search/Search.php" method="GET" class="section_search_section_left_section_main_section_inner_content_blog">
              <input type="text" placeholder="جستجو در میان مقالات..." name="TextSearch" />
            </form>

            <section class="section_Tag_section_left_section_main_section_inner_content_blog">
              <section class="section_tag_section_main_section_inner_content_blog">
                <p>Tag Cloud</p>

                <?php
                $query = "SELECT * FROM `tags`";
                $statement = $conn->prepare($query);
                $statement->execute();
                $Tags = $statement->fetchAll();

                foreach ($Tags as $Tag) {
                ?>
                  <a href="<?= $Tag->LinkTag ?>" class="section_main_tag_section_left_section_main_section_inner_content_blog"><?= $Tag->TextTag ?></a>
                <?php } ?>
              </section>
            </section>

            <section class="section_categories_section_left_section_main_section_inner_content_blog">
              <p class="text_section_categories_section_left_section_main_section_inner_content_blog">
                Categories
              </p>

              <?php
              $query = "SELECT * FROM `categories`";
              $statement = $conn->prepare($query);
              $statement->execute();
              $Categories = $statement->fetchAll();

              foreach ($Categories as $Categorie) {
              ?>
                <section class="section_inner_section_categories_section_left_section_main_section_inner_content_blog">
                  <a href="<?= $Categorie->LinkCategories ?>" class="text_section_inner_section_categories_section_left_section_main_section_inner_content_blog">
                    <?= $Categorie->TextCategories ?>
                  </a>

                  <p class="text_number_section_inner_section_categories_section_left_section_main_section_inner_content_blog">
                    (<?= $Categorie->NumberCategories ?>)
                  </p>
                </section>
              <?php } ?>

            </section>
          </section>
        </section>

        <section class="section_footer_section_inner_content_blog"></section>
      </section>
    </section>

    <section class="section_footer_blog">
      <p>BLOG</p>

      <p>Made by Amir Mohammad</p>
    </section>

    <section class="section_change_theme">
      <i class="fa-regular fa-moon"></i>

      <section class="section_circle_section_change_theme"></section>
    </section>
  </section>
</body>

<section>
  <!-- Start Custom Js -->
  <script src="./Assets/CustomCssJs/Script.js"></script>
  <!-- End Custom Js -->
</section>

</html>