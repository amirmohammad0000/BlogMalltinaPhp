"use strict";

//////////////////////////////////////////////////////////////// Start Variables
let SectionChangeTheme = document.querySelector(".section_change_theme");
let SectionAppBlog = document.querySelector(".section_app_blog");
let SectionHeaderBlog = document.querySelector(".section_header_blog");
let SectionInnerSectionHeaderBlog = document.querySelectorAll(
  ".section_inner_section_header_blog"
);
let SectionInnerSectionHeaderBlogA = document.querySelectorAll(
  ".section_inner_section_header_blog a"
);
let SectionFooterBlog = document.querySelectorAll(".section_footer_blog p");
let TextSectionContentBlogSpan = document.querySelector(
  ".text_section_content_blog span"
);
let SectionInnerContentBlog = document.querySelector(
  ".section_inner_content_blog"
);
let SectionPostSectionInnerContentBlog = document.querySelectorAll(
  ".section_post_section_inner_content_blog"
);
let SectionPostSectionInnerContentBlogA = document.querySelectorAll(
  ".section_post_section_inner_content_blog a"
);
let TextContentSectionPostSectionInnerContentBlog = document.querySelectorAll(
  ".text_content_section_post_section_inner_content_blog"
);
let SectionRowSectionInnerContentBlog = document.querySelectorAll(
  ".section_row_section_inner_content_blog"
);
let SectionFooterSectionInnerContentBlog = document.querySelector(
  ".section_footer_section_inner_content_blog"
);
let SectionMenuSectionInnerSectionHeaderBlogNews = document.querySelector(
  ".section_menu_section_inner_section_header_blog_news"
);
let SectionMenuSectionInnerSectionHeaderBlogContent = document.querySelector(
  ".section_menu_section_inner_section_header_blog_content"
);
let TagASectionMenuSectionInnerSectionHeaderBlogNews =
  document.querySelectorAll(
    ".tag_a_menu_section_menu_section_inner_section_header_blog_news"
  );
let TagASectionMenuSectionInnerSectionHeaderBlogContent =
  document.querySelectorAll(
    ".tag_a_section_menu_section_inner_section_header_blog_content"
  );
let SectionMainSectionInnerContentBlog = document.querySelector(
  ".section_main_section_inner_content_blog"
);
let SectionTextRightSectionMainSectionInnerContentBlog = document.querySelector(
  ".section_text_right_section_main_section_inner_content_blog"
);
let TextSectionRightSectionMainSectionInnerContentBlog = document.querySelector(
  ".text_section_right_section_main_section_inner_content_blog"
);
let SectionCopyAddressPageSectionRight = document.querySelector(
  ".section_copy_address_page_section_right"
);
let SectionPostPrevSectionPostNextPrevSectionRight = document.querySelector(
  ".section_post_prev_section_post_next_prev_section_right i"
);
let SectionPostNextSectionPostNextPrevSectionRight = document.querySelector(
  ".section_post_next_section_post_next_prev_section_right i"
);
let TextSectionCommentSectionCommentsSectionRight = document.querySelectorAll(
  ".text_section_comment_section_comments_section_right"
);
let SectionButtonLoadMoreSectionInnerContentBlog = document.querySelector(
  ".section_button_load_more_section_inner_content_blog"
);
let TextContentCommentSectionCommentSectionCommentsSectionRight =
  document.querySelectorAll(
    ".text_content_comment_section_comment_section_comments_section_right"
  );
let ButtonAnswerSectionCommentSectionCommentsSectionRight =
  document.querySelectorAll(
    ".button_answer_section_comment_section_comments_section_right"
  );
let SectionTextHeaderSectionCommentsSectionRight = document.querySelector(
  ".section_text_header_section_comments_section_right"
);
let ParagraphSectionWriteComment = document.querySelector(
  ".section_write_comment p"
);
let TextAreaSectionTextareaSectionWriteComment = document.querySelector(
  ".section_textarea_section_write_comment textarea"
);
let InputSectionInputSectionWriteComment = document.querySelectorAll(
  ".section_input_section_write_comment input"
);
let SectionButtonSectionWriteComment = document.querySelector(
  ".section_button_section_write_comment"
);
let SectionSearchSectionLeftSectionMainSectionInnerContentBlog =
  document.querySelector(
    ".section_search_section_left_section_main_section_inner_content_blog"
  );
let InputSectionSearchSectionLeftSectionMainSectionInnerContentBlog =
  document.querySelector(
    ".section_search_section_left_section_main_section_inner_content_blog input"
  );
let ParagraphSectionTagSectionMainSectionInnerContentBlog =
  document.querySelector(
    ".section_tag_section_main_section_inner_content_blog p"
  );
let TextSectionCategoriesSectionLeftSectionMainSectionInnerContentBlog =
  document.querySelector(
    ".text_section_categories_section_left_section_main_section_inner_content_blog"
  );
let TextSectionInnerSectionCategoriesSectionLeftSectionMainSectionInnerContentBlog =
  document.querySelectorAll(
    ".text_section_inner_section_categories_section_left_section_main_section_inner_content_blog"
  );
let StatusTheme = true;
//////////////////////////////////////////////////////////////// End Variables

//////////////////////////////////////////////////////////////// Start Function Change Theme
SectionChangeTheme.addEventListener("click", () => {
  if (StatusTheme) {
    FuncSetThemeTrue();
    StatusTheme = false;
  } else {
    FuncSetThemeFalse();
    StatusTheme = true;
  }
});

const FuncSetThemeTrue = () => {
  SectionAppBlog.style.backgroundColor = "#1B2836";
  SectionAppBlog.style.color = "#459BE6";
  SectionHeaderBlog.style.borderColor = "#394654";
  SectionInnerSectionHeaderBlog.forEach((element) => {
    element.style.color = "#459BE6";
  });
  SectionInnerSectionHeaderBlogA.forEach((element) => {
    element.style.color = "#459BE6";
  });
  SectionFooterBlog.forEach((element) => {
    element.style.color = "#f9fcff";
  });
  TextSectionContentBlogSpan.style.color = "#f9fcff";
  SectionInnerContentBlog.style.backgroundColor = "#1B2836";
  SectionPostSectionInnerContentBlog.forEach((element) => {
    element.style.borderColor = "#394654";
  });
  SectionPostSectionInnerContentBlogA.forEach((element) => {
    element.style.color = "#459BE6";
  });
  TextContentSectionPostSectionInnerContentBlog.forEach((element) => {
    element.style.color = "#DAFFFF";
  });
  SectionRowSectionInnerContentBlog.forEach((element) => {
    element.style.borderColor = "#394654";
  });
  SectionFooterSectionInnerContentBlog.style.backgroundColor = "#1B2836";
  SectionMenuSectionInnerSectionHeaderBlogNews.style.backgroundColor =
    "#1B2836";
  SectionMenuSectionInnerSectionHeaderBlogContent.style.backgroundColor =
    "#1B2836";
  TagASectionMenuSectionInnerSectionHeaderBlogNews.forEach((element) => {
    element.style.color = "#459BE6";
  });
  TagASectionMenuSectionInnerSectionHeaderBlogContent.forEach((element) => {
    element.style.color = "#459BE6";
  });
  SectionMainSectionInnerContentBlog.style.backgroundColor = "#1B2836";
  SectionTextRightSectionMainSectionInnerContentBlog.style.color = "#eee";
  TextSectionRightSectionMainSectionInnerContentBlog.style.color = "#eee";
  SectionCopyAddressPageSectionRight.style.backgroundColor = "transparent";
  SectionCopyAddressPageSectionRight.style.color = "#eee";
  SectionCopyAddressPageSectionRight.style.border = "2px solid #394654";
  SectionPostPrevSectionPostNextPrevSectionRight.style.backgroundColor =
    "#1B2836";
  SectionPostNextSectionPostNextPrevSectionRight.style.backgroundColor =
    "#1B2836";
  TextSectionCommentSectionCommentsSectionRight.forEach((element) => {
    element.style.color = "#eee";
  });
  TextContentCommentSectionCommentSectionCommentsSectionRight.forEach(
    (element) => {
      element.style.color = "#eee";
    }
  );
  ButtonAnswerSectionCommentSectionCommentsSectionRight.forEach((element) => {
    element.style.color = "#459BE6";
  });
  SectionTextHeaderSectionCommentsSectionRight.style.color = "#eee";
  ParagraphSectionWriteComment.style.color = "#eee";
  TextAreaSectionTextareaSectionWriteComment.style.backgroundColor =
    "transparent";
  TextAreaSectionTextareaSectionWriteComment.style.border = "2px solid #394654";
  InputSectionInputSectionWriteComment.forEach((element) => {
    element.style.border = "2px solid #394654";
    element.style.backgroundColor = "transparent";
  });
  SectionButtonSectionWriteComment.style.backgroundColor = "transparent";
  SectionButtonSectionWriteComment.style.color = "#eee";
  SectionButtonSectionWriteComment.style.borderColor = "#394654";
  SectionSearchSectionLeftSectionMainSectionInnerContentBlog.style.backgroundColor =
    "transparent";
  InputSectionSearchSectionLeftSectionMainSectionInnerContentBlog.style.backgroundColor =
    "transparent";
  ParagraphSectionTagSectionMainSectionInnerContentBlog.style.color = "#eee";
  TextSectionCategoriesSectionLeftSectionMainSectionInnerContentBlog.style.color =
    "#eee";
  TextSectionInnerSectionCategoriesSectionLeftSectionMainSectionInnerContentBlog.forEach(
    (element) => {
      element.style.color = "#459BE6";
    }
  );
};

const FuncSetThemeFalse = () => {
  SectionAppBlog.style.backgroundColor = "";
  SectionAppBlog.style.color = "";
  SectionHeaderBlog.style.borderColor = "";
  SectionInnerSectionHeaderBlog.forEach((element) => {
    element.style.color = "";
  });
  SectionInnerSectionHeaderBlogA.forEach((element) => {
    element.style.color = "";
  });
  SectionFooterBlog.forEach((element) => {
    element.style.color = "";
  });
  TextSectionContentBlogSpan.style.color = "";
  SectionInnerContentBlog.style.backgroundColor = "";
  SectionPostSectionInnerContentBlog.forEach((element) => {
    element.style.borderColor = "";
  });
  SectionPostSectionInnerContentBlogA.forEach((element) => {
    element.style.color = "";
  });
  TextContentSectionPostSectionInnerContentBlog.forEach((element) => {
    element.style.color = "";
  });
  SectionRowSectionInnerContentBlog.forEach((element) => {
    element.style.borderColor = "";
  });
  SectionFooterSectionInnerContentBlog.style.backgroundColor = "";
  SectionMenuSectionInnerSectionHeaderBlogNews.style.backgroundColor = "";
  SectionMenuSectionInnerSectionHeaderBlogContent.style.backgroundColor = "";
  TagASectionMenuSectionInnerSectionHeaderBlogNews.forEach((element) => {
    element.style.color = "";
  });
  TagASectionMenuSectionInnerSectionHeaderBlogContent.forEach((element) => {
    element.style.color = "";
  });
  SectionMainSectionInnerContentBlog.style.backgroundColor = "";
  SectionTextRightSectionMainSectionInnerContentBlog.style.color = "";
  TextSectionRightSectionMainSectionInnerContentBlog.style.color = "";
  SectionCopyAddressPageSectionRight.style.backgroundColor = "";
  SectionCopyAddressPageSectionRight.style.color = "";
  SectionCopyAddressPageSectionRight.style.border = "";
  SectionPostPrevSectionPostNextPrevSectionRight.style.backgroundColor = "";
  SectionPostNextSectionPostNextPrevSectionRight.style.backgroundColor = "";
  TextSectionCommentSectionCommentsSectionRight.forEach((element) => {
    element.style.color = "";
  });
  TextContentCommentSectionCommentSectionCommentsSectionRight.forEach(
    (element) => {
      element.style.color = "";
    }
  );
  ButtonAnswerSectionCommentSectionCommentsSectionRight.forEach((element) => {
    element.style.color = "";
  });
  SectionTextHeaderSectionCommentsSectionRight.style.color = "";
  ParagraphSectionWriteComment.style.color = "";
  TextAreaSectionTextareaSectionWriteComment.style.backgroundColor = "";
  TextAreaSectionTextareaSectionWriteComment.style.borderColor = "";
  InputSectionInputSectionWriteComment.forEach((element) => {
    element.style.border = "";
    element.style.backgroundColor = "";
  });
  SectionButtonSectionWriteComment.style.backgroundColor = "";
  SectionButtonSectionWriteComment.style.color = "";
  SectionButtonSectionWriteComment.style.borderColor = "";
  SectionSearchSectionLeftSectionMainSectionInnerContentBlog.style.backgroundColor =
    "";
  InputSectionSearchSectionLeftSectionMainSectionInnerContentBlog.style.backgroundColor =
    "";
  ParagraphSectionTagSectionMainSectionInnerContentBlog.style.color = "";
  TextSectionCategoriesSectionLeftSectionMainSectionInnerContentBlog.style.color =
    "";
  TextSectionInnerSectionCategoriesSectionLeftSectionMainSectionInnerContentBlog.forEach(
    (element) => {
      element.style.color = "";
    }
  );
};
//////////////////////////////////////////////////////////////// End Function Change Theme
