<?php
require_once "./../../../Assets/Database/DbConfig.php";
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0" />
  <meta http-equiv="X-UA-Compatible" content="ie=edge" />
  <title>General Information</title>
  <!-- Start Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.0/css/all.min.css" />
  <!-- Start Custom Css -->
  <link rel="stylesheet" href="./Assets/CustomCssJs/Style.css" />
  <!-- End Custom Css -->
</head>

<body>
  <section class="section_app_blog">
    <section class="section_header_blog">
      <section class="section_inner_section_header_blog section_inner_section_header_blog_one">
        <a href="./../../../index.php" class="tag_a_section_inner_section_header_blog">BLOG</a>
      </section>

      <section class="section_inner_section_header_blog">
        <a href="./../../../index.php" class="tag_a_section_inner_section_header_blog">خانه</a>
      </section>

      <section class="section_inner_section_header_blog">
        <a href="https://malltina.com/" class="tag_a_section_inner_section_header_blog">فروشگاه مالتینا</a>
      </section>

      <section class="section_inner_section_header_blog">
        <i class="fa-solid fa-arrow-down"></i>

        <span class="text_open_close_menu_news_and_festivals">
          اخبار و جشنواه‌ها
        </span>

        <section class="section_menu_section_inner_section_header_blog_news">
          <section class="section_inner_menu_section_inner_section_header_blog_news">
            <a href="./../../../Pages/NewsAndFestivals/News/News.php" class="tag_a_menu_section_menu_section_inner_section_header_blog_news">
              اخبار مالتینا
            </a>
          </section>

          <section class="section_inner_menu_section_inner_section_header_blog_news">
            <a href="./../../../Pages/NewsAndFestivals/Festival/Festival.php" class="tag_a_menu_section_menu_section_inner_section_header_blog_news">جشنواره و تخفیف های مالتینا
            </a>
          </section>
        </section>
      </section>

      <section class="section_inner_section_header_blog">
        <i class="fa-solid fa-arrow-down"></i>

        <span class="text_open_close_menu_content">دسته‌بندی مطالب</span>

        <section class="section_menu_section_inner_section_header_blog_content">
          <section class="section_inner_menu_section_inner_section_header_blog_content">
            <a href="./../../../Pages/ContentCategory/GeneralInformation/GeneralInformation.php" class="tag_a_section_menu_section_inner_section_header_blog_content">اطلاعات عمومی</a>
          </section>

          <section class="section_inner_menu_section_inner_section_header_blog_content">
            <a href="./../../../Pages/ContentCategory/WomenMagazine/WomenMagazine.php" class="tag_a_section_menu_section_inner_section_header_blog_content">
              مجله بانوان
            </a>
          </section>

          <section class="section_inner_menu_section_inner_section_header_blog_content">
            <a href="./../../../Pages/ContentCategory/ScienceAndTechnology/ScienceAndTechnology.php" class="tag_a_section_menu_section_inner_section_header_blog_content">
              علم و تکنولوژی
            </a>
          </section>

          <section class="section_inner_menu_section_inner_section_header_blog_content">
            <a href="./../../../Pages/ContentCategory/WorldArtAndCinema/WorldArtAndCinema.php" class="tag_a_section_menu_section_inner_section_header_blog_content">
              هنر و سینمای جهان
            </a>
          </section>

          <section class="section_inner_menu_section_inner_section_header_blog_content">
            <a href="./../../../Pages/ContentCategory/ReviewAndDownloadMoviesAndSeries/ReviewAndDownloadMoviesAndSeries.php" class="tag_a_section_menu_section_inner_section_header_blog_content">
              نقد و دانلود فیلم و سریال
            </a>
          </section>

          <section class="section_inner_menu_section_inner_section_header_blog_content">
            <a href="./../../../Pages/ContentCategory/ModeAndFashion/ModeAndFashion.php" class="tag_a_section_menu_section_inner_section_header_blog_content">
              مد و فشن</a>
          </section>

          <section class="section_inner_menu_section_inner_section_header_blog_content">
            <a href="./../../../Pages/ContentCategory/ProductIntroduction/ProductIntroduction.php" class="tag_a_section_menu_section_inner_section_header_blog_content">
              معرفی محصول
            </a>
          </section>

          <section class="section_inner_menu_section_inner_section_header_blog_content">
            <a href="./../../../Pages/ContentCategory/SkillsAndBusiness/SkillsAndBusiness.php" class="tag_a_section_menu_section_inner_section_header_blog_content">
              مهارت و کسب‌ و کار
            </a>
          </section>

          <section class="section_inner_menu_section_inner_section_header_blog_content">
            <a href="./../../../Pages/ContentCategory/Other/Other.php" class="tag_a_section_menu_section_inner_section_header_blog_content">
              سایر
            </a>
          </section>
        </section>
      </section>

      <section class="section_inner_section_header_blog">
        <a href="./../../../Pages/PurchaseGuide/PurchaseGuide.php" class="tag_a_section_inner_section_header_blog">راهنمای خرید</a>
      </section>

      <section class="section_inner_section_header_blog">
        <a href="./../../../index.php" class="tag_a_section_inner_section_header_blog">RSS</a>
      </section>
    </section>

    <section class="section_content_blog">
      <p class="text_section_content_blog">
        سلام! ما <span>345</span> محتوای تخصصی برای شما آماده کرده‌ایم
      </p>

      <section class="section_inner_content_blog">
        <section class="section_main_section_inner_content_blog">
          <section class="section_tag_section_main_section_inner_content_blog">
            <p>Tag Cloud</p>


            <?php
            $query = "SELECT * FROM `tags`";
            $statement = $conn->prepare($query);
            $statement->execute();
            $Tags = $statement->fetchAll();

            foreach ($Tags as $Tag) {
            ?>
              <a href="<?= $Tag->LinkTag ?>" class="section_main_tag_section_tag_section_main_section_inner_content_blog"><?= $Tag->TextTag ?></a>
            <?php } ?>
          </section>

          <section class="section_posts_section_main_section_inner_content_blog">
            <?php
            $query = "SELECT * FROM `posts` WHERE `StatusPosts` = 1";
            $statement = $conn->prepare($query);
            $statement->execute();
            $posts = $statement->fetchAll();

            foreach ($posts as $post) {
            ?>
              <section class="section_post_section_main_section_inner_content_blog">
                <img class="image_section_post_section_main_section_inner_content_blog" src="./../../../<?= $post->ImagePost ?>" alt="Post" />

                <p class="text_header_section_post_section_main_section_inner_content_blog">
                  <?= $post->TitlePost ?>
                </p>

                <p class="text_content_section_post_section_main_section_inner_content_blog">
                  <?= $post->ContentPost ?>
                </p>

                <a href="./../../Posts/Posts.php?PostId=<?= $post->Id ?>" class="section_button_section_post_section_main_section_inner_content_blog">
                  Continue reading
                </a>
              </section>
            <?php } ?>

            <section class="section_main_button_load_more_section_inner_content_blog">
              <section class="section_button_load_more_section_inner_content_blog">
                Load More
              </section>
            </section>
          </section>
        </section>

        <section class="section_footer_section_inner_content_blog"></section>
      </section>
    </section>

    <section class="section_footer_blog">
      <p>BLOG</p>

      <p>Made by Amir Mohammad</p>
    </section>

    <section class="section_change_theme">
      <i class="fa-regular fa-moon"></i>

      <section class="section_circle_section_change_theme"></section>
    </section>
  </section>
</body>

<section>
  <!-- Start Custom Js -->
  <script src="./Assets/CustomCssJs/Script.js"></script>
  <!-- End Custom Js -->
</section>

</html>